var add = function(a,b){
	var r = [];
	for(var i = 0; i < a.length; i++){
		r[i] = [];
		for(var j = 0; j < a[i].length; j++){
			r[i][j] = a[i][j] + b[i][j];
		}
	}
	return r;
}

var a = [[3,2,1],[1,2,3]];
var b = add(a,a);

console.log("a = %j", a);
console.log("b = %j", b);
