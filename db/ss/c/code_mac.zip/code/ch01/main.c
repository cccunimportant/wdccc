#include <stdio.h>

int main(void) {
  int sum1 = sum(10);
  printf("sum=%d\n", sum1);
  system("pause");
  return 1;
}
