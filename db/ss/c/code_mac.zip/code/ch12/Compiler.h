#ifndef COMPILER_H

#include "Parser.h"
#include "Generator.h"

void compile(char *cFile, char *asmFile);

#endif
