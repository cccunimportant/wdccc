# 1 "macro.c"
# 1 "<built-in>"
# 1 "<command line>"
# 1 "macro.c"



int main() {
  int x = (3>5?3:5);
  int y = (3<5?3:5);
  printf("max(3,5)=%d\n", x);
  printf("min(3,5)=%d\n", y);
}
