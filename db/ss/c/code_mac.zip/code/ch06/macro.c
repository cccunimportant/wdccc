#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)

int main() {
  int x = max(3,5);
  int y = min(3,5);
  printf("max(3,5)=%d\n", x);
  printf("min(3,5)=%d\n", y);
}
