#include <stdio.h>

int main() {
	int x = 1;
	int y;
	y = f1(x);
	printf("y=%d\n", y);
	return 1;
}
