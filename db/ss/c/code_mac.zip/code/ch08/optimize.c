int f() {
  int a=3, b=4, c, d;
  c=a+b;
  d=a+b;
  return c+d;
}
