extern void push(int x);
extern int pop();

int main() {
  int x;
  push(3);
  x= pop();
  return 0;
}
