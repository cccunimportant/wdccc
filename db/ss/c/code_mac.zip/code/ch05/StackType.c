int stack[128];
int top = 0;

