#include <stdio.h>

int main(void) {
  printf("asmMain()=%d\n", asmMain());
}

