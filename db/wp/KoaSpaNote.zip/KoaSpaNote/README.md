# KoaSpaNote

A Note System (Io.js + Koa, Single Page Application)

## Run

> npm install

> iojs KoaNoteServer

After the server startup, you may type http://localhost:3000/ to use the note system.
