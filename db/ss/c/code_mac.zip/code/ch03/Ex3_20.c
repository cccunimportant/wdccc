struct {

  char name[20];
  int age;

} person[10];

int sum = 0;

int main() {
  person[0].age = 1;
}

