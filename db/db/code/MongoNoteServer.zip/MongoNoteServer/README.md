# MongoNoteServer

A Note System store data in MongoDB (Io.js + Koa, Single Page Application)

## Run

> npm install

> iojs MongoNoteServer

After the server startup, you may type http://localhost:3000/ to use the note system.
