#include <stdio.h>

int main(void) {
  printf("hello !\n");
  system("pause");
  return 1;
}
