#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define UINT16 unsigned short
#define BYTE unsigned char
#define MAX_LEN 100
#define WORD 0xFF
#define LD   0x0
#define ADD  0x1
#define JMP  0x2
#define ST   0x3
#define CMP  0x4
#define JEQ  0x5
#define RET  0xE

typedef struct {
  char *name;
  int  value; 
} Pair;

int opTop  = 8;
Pair opTable[] = {{"WORD", WORD}, {"LD", LD}, {"ADD", ADD},{"JMP", JMP}, 
                  {"ST", ST}, {"CMP", CMP}, {"JEQ", JEQ}, {"RET", RET}};

Pair *table_get(Pair *table, int top, char *name) {
  int i;
  for (i=0; i<top; i++) {
    if (strcmp(name, table[i].name)==0)
      return &table[i];
  }
  return NULL;
}

int table_put(Pair *table, int *top, char *name, int value) {
  Pair *pair = table_get(table, *top, name);
  if (pair == NULL) {
    pair = &table[*top];
    pair->value = value;
    pair->name = strdup(name);
    (*top)++;
    return 1;
  } 
  return 0;
}

int main() {
  Pair* pair = table_get(opTable, opTop, "ADD");
  printf("op=%d", pair->value);
}

