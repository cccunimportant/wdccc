取得游標的位置 -- 
* 讚 http://jsfiddle.net/NFJ9r/132/

https://github.com/component/textarea-caret-position