#!/bin/bash
node ../tool/mt8file.js ../corpus/test.html > test_mt.html
