#!/bin/bash
browserify baji.js > ../web/baji.js